/**
 * Created by qingyun on 16/11/6.
 */

angular.module('myApp.cartoonDetailController', [])
    .controller('cartoonDetailController', function ($scope,myFactory,$stateParams) {

        $scope.mine = {

        };

        console.log($stateParams)


    })